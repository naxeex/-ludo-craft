import React from 'react';
import { X, Shield, Award, RotateCw, Dices, ArrowRight } from 'lucide-react';
import { sounds } from '../audio/soundEffects';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 pointer-events-auto select-none">
      <div className="w-full max-w-lg max-h-[85vh] overflow-y-auto p-6 rounded-2xl bg-stone-900 border border-stone-700 shadow-2xl text-stone-100 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-stone-800 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Dices className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-black tracking-tight text-white uppercase">
              How to Play Ludo
            </h3>
          </div>
          <button
            onClick={() => {
              sounds.playButtonClick();
              onClose();
            }}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs text-stone-300 leading-relaxed">
          {/* Rule 1: Leaving the Yard */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-stone-950/70 border border-stone-800">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
              <span className="font-black text-sm">6</span>
            </div>
            <div>
              <h4 className="font-bold text-white text-sm mb-0.5">The Magic Six</h4>
              <p>
                Tokens start inside your colored Yard. You must roll a <strong className="text-amber-400">6</strong> to release a pawn onto your starting track tile. Rolling a 6 also awards an immediate <strong className="text-amber-400">bonus roll</strong>!
              </p>
            </div>
          </div>

          {/* Rule 2: Safe Squares */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-stone-950/70 border border-stone-800">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm mb-0.5">Safe Star Havens</h4>
              <p>
                Squares marked with a <strong className="text-amber-400">Star (★)</strong> and starting tiles are sanctuary zones. Pawns resting here are immune to capture and cannot be attacked.
              </p>
            </div>
          </div>

          {/* Rule 3: Capturing Opponents */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-stone-950/70 border border-stone-800">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <RotateCw className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm mb-0.5">Captures & Bonus Turns</h4>
              <p>
                Landing directly on an opponent's pawn in an unsafe tile captures it, banishing it back to their yard! Every successful capture grants an immediate <strong className="text-emerald-400">bonus roll</strong>.
              </p>
            </div>
          </div>

          {/* Rule 4: Home Column & Goal */}
          <div className="flex items-start gap-3 p-3 rounded-xl bg-stone-950/70 border border-stone-800">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm mb-0.5">Home Stretch & Victory</h4>
              <p>
                Complete a full circuit of the perimeter and turn into your color's private home column. An <strong className="text-blue-400">exact roll</strong> is required to enter the center Goal. First player to escort all 4 pawns home wins!
              </p>
            </div>
          </div>

          {/* Keyboard & Controls */}
          <div className="p-3 rounded-xl bg-stone-950/40 border border-stone-800 text-[11px] text-stone-400 font-mono">
            <div className="font-bold text-stone-300 uppercase mb-1">Shortcut Controls:</div>
            <div>• <strong className="text-amber-300">Spacebar:</strong> Roll dice</div>
            <div>• <strong className="text-amber-300">Click Token:</strong> Move selected pawn</div>
            <div>• <strong className="text-amber-300">Left Drag:</strong> 3D Orbit Camera</div>
            <div>• <strong className="text-amber-300">Scroll:</strong> Zoom in / out</div>
            <div>• <strong className="text-amber-300">H:</strong> Toggle bottom dock</div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-stone-800">
          <button
            onClick={() => {
              sounds.playButtonClick();
              onClose();
            }}
            className="w-full py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
          >
            Got It, Let's Play!
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { PlayerColor, PlayerConfig, PlayerStats } from '../types/ludo';
import { COLOR_HEX } from '../utils/ludoRules';
import { Trophy, RotateCcw, Home, Crown, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../audio/soundEffects';

interface VictoryModalProps {
  winner: PlayerConfig;
  players: PlayerConfig[];
  stats: Map<PlayerColor, PlayerStats>;
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  winner,
  players,
  stats,
  onPlayAgain,
  onMainMenu,
}) => {
  const winnerHex = COLOR_HEX[winner.color];

  React.useEffect(() => {
    sounds.playVictoryFanfare();

    // Multi-stage celebratory confetti cannons
    const duration = 3 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: [winnerHex.main, '#FBBF24', '#FFFFFF'],
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: [winnerHex.main, '#FBBF24', '#FFFFFF'],
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  }, [winner]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 pointer-events-auto select-none">
      <div className="w-full max-w-md p-6 rounded-2xl bg-stone-900 border-2 border-amber-400/80 shadow-2xl text-center text-stone-100 animate-in fade-in zoom-in duration-300">
        {/* Trophy Icon */}
        <div className="w-20 h-20 rounded-2xl mx-auto flex items-center justify-center bg-gradient-to-br from-amber-400 to-amber-600 shadow-xl shadow-amber-500/20 mb-3">
          <Trophy className="w-10 h-10 text-stone-950" />
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40 mb-2">
          <Crown className="w-3.5 h-3.5" /> Champion Declared
        </div>

        <h2 className="text-3xl font-black uppercase tracking-tight text-white">
          <span style={{ color: winnerHex.light }}>{winner.name}</span> Wins!
        </h2>
        <p className="text-stone-400 text-xs mt-1 mb-5">
          All 4 royal tokens have safely journeyed to the golden center sanctuary.
        </p>

        {/* Players Standings */}
        <div className="bg-stone-950/70 rounded-xl p-3 border border-stone-800 text-left mb-6 space-y-2">
          <div className="text-[10px] uppercase font-bold tracking-wider text-stone-500 px-1">
            Match Standings
          </div>
          {players.map((p) => {
            const isW = p.color === winner.color;
            const pStats = stats.get(p.color);
            return (
              <div
                key={p.color}
                className={`flex items-center justify-between p-2 rounded-lg text-xs ${
                  isW ? 'bg-amber-500/10 border border-amber-500/30' : 'bg-stone-900/60'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLOR_HEX[p.color].main }}
                  />
                  <span className={`font-semibold ${isW ? 'text-amber-300' : 'text-stone-300'}`}>
                    {p.name}
                  </span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[11px] tabular-nums text-stone-400">
                  <span>Goal: {pStats?.tokensHome ?? 0}/4</span>
                  <span>Captures: {pStats?.kills ?? 0}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTAs */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sounds.playButtonClick();
              onPlayAgain();
            }}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-stone-950 font-black text-sm uppercase tracking-wider shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again</span>
          </button>
          <button
            onClick={() => {
              sounds.playButtonClick();
              onMainMenu();
            }}
            className="flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>Menu</span>
          </button>
        </div>
      </div>
    </div>
  );
};

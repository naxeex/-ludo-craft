import React from 'react';
import { PlayerColor, GamePhase, PlayerConfig } from '../types/ludo';
import { COLOR_HEX } from '../utils/ludoRules';
import { Bot, User, Dices } from 'lucide-react';

interface TurnBannerProps {
  activePlayer: PlayerConfig;
  gamePhase: GamePhase;
  diceRoll: number | null;
  message: string;
  consecutiveSixes: number;
}

export const TurnBanner: React.FC<TurnBannerProps> = ({
  activePlayer,
  gamePhase,
  diceRoll,
  message,
  consecutiveSixes,
}) => {
  const colorInfo = COLOR_HEX[activePlayer.color];

  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-none flex flex-col items-center gap-1.5 max-w-[92vw]">
      {/* Sleek status capsule */}
      <div className="flex items-center gap-3 px-4 py-2 rounded-full bg-stone-900/95 border border-stone-700/80 shadow-2xl text-stone-100 select-none">
        {/* Color badge */}
        <div className="flex items-center gap-2">
          <div
            className="w-3.5 h-3.5 rounded-full shadow-sm ring-2 ring-white/20"
            style={{ backgroundColor: colorInfo.main }}
          />
          <span className="font-bold text-sm tracking-wide capitalize text-white">
            {activePlayer.name}
          </span>
          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-stone-800 text-stone-300 border border-stone-700">
            {activePlayer.type === 'ai' ? (
              <span className="flex items-center gap-1">
                <Bot className="w-3 h-3 text-indigo-400" /> AI
              </span>
            ) : (
              <span className="flex items-center gap-1">
                <User className="w-3 h-3 text-emerald-400" /> You
              </span>
            )}
          </span>
        </div>

        <div className="h-4 w-px bg-stone-700" />

        {/* Dice Readout */}
        <div className="flex items-center gap-1.5 font-mono text-sm tabular-nums">
          <Dices className="w-4 h-4 text-amber-400" />
          {diceRoll ? (
            <span className="font-black text-amber-300 text-base">{diceRoll}</span>
          ) : (
            <span className="text-stone-500">-</span>
          )}
        </div>

        {consecutiveSixes > 1 && (
          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            {consecutiveSixes}x SIX!
          </span>
        )}
      </div>

      {/* Dynamic Subtitle Feedback */}
      {message && (
        <div className="px-3 py-1 rounded-md bg-stone-950/85 border border-stone-800 text-xs font-medium text-stone-300 shadow-md">
          {message}
        </div>
      )}
    </div>
  );
};

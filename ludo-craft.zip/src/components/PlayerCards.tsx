import React from 'react';
import { PlayerColor, Token, PlayerConfig } from '../types/ludo';
import { COLOR_HEX } from '../utils/ludoRules';
import { Home, Compass, Trophy } from 'lucide-react';

interface PlayerCardsProps {
  players: PlayerConfig[];
  tokens: Token[];
  activeColor: PlayerColor;
}

export const PlayerCards: React.FC<PlayerCardsProps> = ({
  players,
  tokens,
  activeColor,
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none p-4 select-none flex flex-col justify-between">
      {/* Top Row: Red (Left) and Green (Right) */}
      <div className="flex justify-between items-start">
        {renderPlayerCard(players.find((p) => p.color === 'red'), tokens, activeColor)}
        {renderPlayerCard(players.find((p) => p.color === 'green'), tokens, activeColor)}
      </div>

      {/* Bottom Row: Blue (Left) and Yellow (Right) */}
      <div className="flex justify-between items-end mb-16">
        {renderPlayerCard(players.find((p) => p.color === 'blue'), tokens, activeColor)}
        {renderPlayerCard(players.find((p) => p.color === 'yellow'), tokens, activeColor)}
      </div>
    </div>
  );
};

function renderPlayerCard(
  player: PlayerConfig | undefined,
  tokens: Token[],
  activeColor: PlayerColor
) {
  if (!player || !player.active) return <div className="w-36 md:w-44" />;

  const isActive = player.color === activeColor;
  const hex = COLOR_HEX[player.color];
  const playerTokens = tokens.filter((t) => t.color === player.color);

  const inYard = playerTokens.filter((t) => t.step === -1).length;
  const inGoal = playerTokens.filter((t) => t.isFinished).length;
  const onTrack = 4 - inYard - inGoal;

  return (
    <div
      className={`w-36 md:w-44 p-2.5 rounded-xl border transition-all pointer-events-auto bg-stone-900/90 shadow-xl ${
        isActive
          ? 'border-amber-400 ring-2 ring-amber-400/30'
          : 'border-stone-800/80 opacity-85'
      }`}
    >
      <div className="flex items-center justify-between gap-1 mb-2">
        <div className="flex items-center gap-1.5 truncate">
          <div
            className="w-3 h-3 rounded-full shrink-0 shadow-sm"
            style={{ backgroundColor: hex.main }}
          />
          <span className="text-xs font-bold text-stone-200 truncate capitalize">
            {player.name}
          </span>
        </div>
        {isActive && (
          <span className="text-[9px] font-black uppercase tracking-wider px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0">
            TURN
          </span>
        )}
      </div>

      {/* 3 Metrics: Yard, Track, Goal */}
      <div className="grid grid-cols-3 gap-1 text-[11px] font-mono tabular-nums text-center">
        <div className="flex flex-col items-center bg-stone-950/60 rounded p-1" title="Tokens in Yard">
          <span className="text-[9px] text-stone-500 uppercase flex items-center gap-0.5">
            <Home className="w-2.5 h-2.5" /> Yard
          </span>
          <span className="font-bold text-stone-300">{inYard}</span>
        </div>
        <div className="flex flex-col items-center bg-stone-950/60 rounded p-1" title="Tokens on Track">
          <span className="text-[9px] text-stone-500 uppercase flex items-center gap-0.5">
            <Compass className="w-2.5 h-2.5" /> Track
          </span>
          <span className="font-bold text-stone-300">{onTrack}</span>
        </div>
        <div className="flex flex-col items-center bg-stone-950/60 rounded p-1" title="Tokens Finished">
          <span className="text-[9px] text-stone-500 uppercase flex items-center gap-0.5">
            <Trophy className="w-2.5 h-2.5" /> Goal
          </span>
          <span className="font-bold text-amber-400">{inGoal}/4</span>
        </div>
      </div>
    </div>
  );
}

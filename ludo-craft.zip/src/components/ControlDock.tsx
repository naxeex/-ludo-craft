import React from 'react';
import {
  PlayerColor,
  GamePhase,
  CameraPreset,
  BoardTheme,
  MoveOption,
  PlayerConfig,
} from '../types/ludo';
import { COLOR_HEX } from '../utils/ludoRules';
import {
  Dices,
  Volume2,
  VolumeX,
  HelpCircle,
  RotateCcw,
  Eye,
  Palette,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { sounds } from '../audio/soundEffects';

interface ControlDockProps {
  activePlayer: PlayerConfig;
  gamePhase: GamePhase;
  onRollDice: () => void;
  validMoves: MoveOption[];
  onSelectToken: (tokenId: number) => void;
  currentCamera: CameraPreset;
  onCameraChange: (preset: CameraPreset) => void;
  currentTheme: BoardTheme;
  onThemeChange: (theme: BoardTheme) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenRules: () => void;
  onRestart: () => void;
}

export const ControlDock: React.FC<ControlDockProps> = ({
  activePlayer,
  gamePhase,
  onRollDice,
  validMoves,
  onSelectToken,
  currentCamera,
  onCameraChange,
  currentTheme,
  onThemeChange,
  isMuted,
  onToggleMute,
  onOpenRules,
  onRestart,
}) => {
  const [isCollapsed, setIsCollapsed] = React.useState(false);

  // Toggle collapse on 'H' key
  React.useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'h' || e.key === 'H') {
        setIsCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const canRoll = activePlayer.type === 'human' && gamePhase === 'waiting_for_roll';
  const isSelecting = activePlayer.type === 'human' && gamePhase === 'selecting_token';

  const hex = COLOR_HEX[activePlayer.color];

  return (
    <div
      className={`fixed bottom-3 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center transition-transform duration-300 pointer-events-auto select-none ${
        isCollapsed ? 'translate-y-[calc(100%-28px)]' : 'translate-y-0'
      }`}
      style={{ maxWidth: 'min(940px, 94vw)' }}
    >
      {/* Collapse Toggle Tab */}
      <button
        onClick={() => {
          sounds.playButtonClick();
          setIsCollapsed((prev) => !prev);
        }}
        className="flex items-center gap-1 px-3 py-1 text-[11px] font-semibold text-stone-300 hover:text-white bg-stone-900 border-t border-x border-stone-700/80 rounded-t-lg shadow-lg cursor-pointer transition-colors"
      >
        {isCollapsed ? (
          <>
            <ChevronUp className="w-3.5 h-3.5 text-amber-400" /> Show Controls [H]
          </>
        ) : (
          <>
            <ChevronDown className="w-3.5 h-3.5 text-stone-400" /> Hide [H]
          </>
        )}
      </button>

      {/* Main Consolidated Bottom Dock */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 p-3 bg-stone-900 border border-stone-700/80 rounded-2xl shadow-2xl text-stone-200">
        {/* Left: Primary Roll / Action cluster */}
        <div className="flex items-center gap-2">
          {canRoll ? (
            <button
              onClick={() => {
                sounds.playButtonClick();
                onRollDice();
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-black text-sm uppercase tracking-wider text-stone-950 shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
              style={{ backgroundColor: hex.main }}
            >
              <Dices className="w-5 h-5" />
              <span>Roll Dice (Space)</span>
            </button>
          ) : isSelecting ? (
            <div className="flex items-center gap-1.5 bg-stone-950 px-3 py-1.5 rounded-xl border border-stone-800">
              <span className="text-xs font-bold text-amber-300">Choose token:</span>
              <div className="flex items-center gap-1">
                {validMoves.map((m) => (
                  <button
                    key={m.tokenId}
                    onClick={() => onSelectToken(m.tokenId)}
                    className="w-8 h-8 rounded-lg font-bold text-xs flex items-center justify-center text-white border border-white/20 hover:scale-110 active:scale-95 transition-transform"
                    style={{ backgroundColor: hex.main }}
                    title={`Move token #${m.tokenId + 1}`}
                  >
                    #{m.tokenId + 1}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-950 text-stone-400 text-xs font-semibold border border-stone-800">
              <Dices className="w-4 h-4 text-stone-500" />
              <span>{activePlayer.type === 'ai' ? 'Bot is thinking...' : 'Wait for turn'}</span>
            </div>
          )}
        </div>

        {/* Center: Camera View Presets */}
        <div className="flex items-center gap-1 bg-stone-950/80 p-1 rounded-xl border border-stone-800">
          <span className="text-[10px] font-bold text-stone-500 px-1 uppercase flex items-center gap-1">
            <Eye className="w-3 h-3" /> View:
          </span>
          {(['perspective', 'topdown', 'isometric'] as CameraPreset[]).map((cam) => (
            <button
              key={cam}
              onClick={() => {
                sounds.playButtonClick();
                onCameraChange(cam);
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                currentCamera === cam
                  ? 'bg-amber-400 text-stone-950 font-bold shadow'
                  : 'text-stone-400 hover:text-white hover:bg-stone-800'
              }`}
            >
              {cam === 'perspective' ? '3D Orbit' : cam === 'topdown' ? '2D Board' : 'Isometric'}
            </button>
          ))}
        </div>

        {/* Right: Theme, Sound, Rules, Restart */}
        <div className="flex items-center gap-1.5">
          {/* Theme Quick Switcher */}
          <button
            onClick={() => {
              sounds.playButtonClick();
              const themes: BoardTheme[] = ['royal', 'classic', 'neon', 'marble'];
              const nextIdx = (themes.indexOf(currentTheme) + 1) % themes.length;
              onThemeChange(themes[nextIdx]);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-medium transition-colors"
            title="Cycle Board Theme"
          >
            <Palette className="w-3.5 h-3.5 text-amber-400" />
            <span className="capitalize hidden sm:inline">{currentTheme}</span>
          </button>

          {/* Sound Mute */}
          <button
            onClick={() => {
              sounds.playButtonClick();
              onToggleMute();
            }}
            className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-stone-300" />}
          </button>

          {/* Rules */}
          <button
            onClick={() => {
              sounds.playButtonClick();
              onOpenRules();
            }}
            className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 transition-colors"
            title="How to Play"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
          </button>

          {/* Restart */}
          <button
            onClick={() => {
              sounds.playButtonClick();
              onRestart();
            }}
            className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-red-400 transition-colors"
            title="Restart Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { PlayerColor, PlayerConfig, BoardTheme } from '../types/ludo';
import { COLOR_HEX, PLAYERS_ORDER } from '../utils/ludoRules';
import { Crown, Sparkles, Volume2, VolumeX, Shield, Play, HelpCircle } from 'lucide-react';
import { sounds } from '../audio/soundEffects';

interface TitleScreenProps {
  onStartGame: (players: PlayerConfig[], theme: BoardTheme) => void;
  onOpenRules: () => void;
  currentTheme: BoardTheme;
  onThemeChange: (theme: BoardTheme) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStartGame,
  onOpenRules,
  currentTheme,
  onThemeChange,
  isMuted,
  onToggleMute,
}) => {
  const [presetMode, setPresetMode] = React.useState<'solo' | 'duo' | 'party' | 'custom'>('solo');
  const [players, setPlayers] = React.useState<PlayerConfig[]>([
    { color: 'red', name: 'Player 1', type: 'human', active: true },
    { color: 'green', name: 'AI Green', type: 'ai', active: true },
    { color: 'yellow', name: 'AI Yellow', type: 'ai', active: true },
    { color: 'blue', name: 'AI Blue', type: 'ai', active: true },
  ]);

  const handleModeChange = (mode: 'solo' | 'duo' | 'party' | 'custom') => {
    sounds.playButtonClick();
    setPresetMode(mode);

    if (mode === 'solo') {
      setPlayers([
        { color: 'red', name: 'You (Red)', type: 'human', active: true },
        { color: 'green', name: 'AI Green', type: 'ai', active: true },
        { color: 'yellow', name: 'AI Yellow', type: 'ai', active: true },
        { color: 'blue', name: 'AI Blue', type: 'ai', active: true },
      ]);
    } else if (mode === 'duo') {
      setPlayers([
        { color: 'red', name: 'Player 1', type: 'human', active: true },
        { color: 'green', name: 'AI Green', type: 'ai', active: true },
        { color: 'yellow', name: 'Player 2', type: 'human', active: true },
        { color: 'blue', name: 'AI Blue', type: 'ai', active: true },
      ]);
    } else if (mode === 'party') {
      setPlayers([
        { color: 'red', name: 'Player 1', type: 'human', active: true },
        { color: 'green', name: 'Player 2', type: 'human', active: true },
        { color: 'yellow', name: 'Player 3', type: 'human', active: true },
        { color: 'blue', name: 'Player 4', type: 'human', active: true },
      ]);
    }
  };

  const togglePlayerType = (index: number) => {
    sounds.playButtonClick();
    setPlayers((prev) => {
      const next = [...prev];
      const p = next[index];
      if (p.type === 'human') {
        p.type = 'ai';
        p.name = `AI ${p.color.toUpperCase()}`;
      } else {
        p.type = 'human';
        p.name = `Player (${p.color.toUpperCase()})`;
      }
      return next;
    });
  };

  const togglePlayerActive = (index: number) => {
    sounds.playButtonClick();
    setPlayers((prev) => {
      const activeCount = prev.filter((p) => p.active).length;
      if (prev[index].active && activeCount <= 2) return prev; // At least 2 active players

      const next = [...prev];
      next[index] = { ...next[index], active: !next[index].active };
      return next;
    });
  };

  const handleStart = () => {
    sounds.playTokenEnter();
    onStartGame(players, currentTheme);
  };

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        handleStart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [players, currentTheme]);

  return (
    <div className="absolute inset-0 z-40 flex flex-col items-center justify-between pointer-events-auto bg-gradient-to-b from-stone-950/85 via-stone-900/75 to-stone-950/90 text-stone-100 p-6 md:p-8 select-none overflow-y-auto">
      {/* Top Header Controls */}
      <div className="w-full max-w-4xl flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-wider">
            <Crown className="w-3.5 h-3.5" /> 3D Board Edition
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sounds.playButtonClick();
              onOpenRules();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700 text-stone-300 hover:text-white text-xs font-medium transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" /> Rules
          </button>
          <button
            onClick={() => {
              sounds.playButtonClick();
              onToggleMute();
            }}
            className="p-2 rounded-lg bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700 text-stone-300 hover:text-white transition-colors"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-stone-300" />}
          </button>
        </div>
      </div>

      {/* Hero Centerpiece & Title Lockup */}
      <div className="flex flex-col items-center text-center my-auto max-w-2xl">
        <div className="relative mb-3">
          {/* Bespoke Royal Crown & Star Lockup */}
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-700 flex items-center justify-center shadow-2xl shadow-amber-500/20 border border-amber-300/40 mx-auto">
            <Crown className="w-11 h-11 text-amber-950" />
          </div>
          <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-red-600 border-2 border-stone-900 flex items-center justify-center text-white text-[10px] font-bold">
            ★
          </div>
        </div>

        <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white uppercase drop-shadow-md">
          Royal Ludo <span className="text-amber-400">3D</span>
        </h1>
        <p className="mt-2 text-stone-400 text-sm md:text-base max-w-md">
          A physical tabletop classic brought to life with 3D board physics, realistic pawn hops, smart AI, and local Pass & Play.
        </p>

        {/* Mode Selector */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 p-1.5 rounded-xl bg-stone-900/90 border border-stone-800 shadow-inner">
          <button
            onClick={() => handleModeChange('solo')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
              presetMode === 'solo'
                ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-800'
            }`}
          >
            1 vs 3 AI (Solo)
          </button>
          <button
            onClick={() => handleModeChange('duo')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
              presetMode === 'duo'
                ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-800'
            }`}
          >
            2 Players + 2 AI
          </button>
          <button
            onClick={() => handleModeChange('party')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
              presetMode === 'party'
                ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-800'
            }`}
          >
            4 Players (Local)
          </button>
          <button
            onClick={() => handleModeChange('custom')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
              presetMode === 'custom'
                ? 'bg-amber-500 text-stone-950 shadow-md font-bold'
                : 'text-stone-400 hover:text-white hover:bg-stone-800'
            }`}
          >
            Custom
          </button>
        </div>

        {/* Players Configuration Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 w-full mt-4">
          {players.map((p, idx) => {
            const hex = COLOR_HEX[p.color];
            return (
              <div
                key={p.color}
                className={`flex flex-col items-center p-3 rounded-xl border transition-all ${
                  p.active
                    ? 'bg-stone-900/90 border-stone-700/80 shadow-md'
                    : 'bg-stone-950/40 border-stone-800/40 opacity-40'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-4 h-4 rounded-full shadow"
                    style={{ backgroundColor: hex.main }}
                  />
                  <span className="text-xs font-bold text-stone-200 capitalize">
                    {p.color}
                  </span>
                </div>

                <div className="text-xs text-stone-400 mb-2 font-medium truncate max-w-[120px]">
                  {p.name}
                </div>

                {presetMode === 'custom' && (
                  <div className="flex items-center gap-1.5 w-full justify-center">
                    <button
                      onClick={() => togglePlayerType(idx)}
                      disabled={!p.active}
                      className="text-[10px] px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 font-medium"
                    >
                      {p.type === 'human' ? 'Human' : 'AI'}
                    </button>
                    <button
                      onClick={() => togglePlayerActive(idx)}
                      className={`text-[10px] px-2 py-0.5 rounded font-medium ${
                        p.active ? 'bg-red-950/80 text-red-300 hover:bg-red-900' : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {p.active ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                )}
                {presetMode !== 'custom' && (
                  <span
                    className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                      p.type === 'human'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                    }`}
                  >
                    {p.type === 'human' ? 'Player' : 'Bot AI'}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Board Theme Selector */}
        <div className="mt-5 flex items-center justify-center gap-2">
          <span className="text-xs text-stone-400 font-medium mr-1">Theme:</span>
          {(['royal', 'classic', 'neon', 'marble'] as BoardTheme[]).map((theme) => (
            <button
              key={theme}
              onClick={() => {
                sounds.playButtonClick();
                onThemeChange(theme);
              }}
              className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${
                currentTheme === theme
                  ? 'bg-amber-400 text-stone-950 shadow-md font-bold'
                  : 'bg-stone-900/80 text-stone-400 hover:text-white border border-stone-800'
              }`}
            >
              {theme}
            </button>
          ))}
        </div>

        {/* Big Start CTA Button */}
        <div className="mt-6">
          <button
            onClick={handleStart}
            className="group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-black text-lg uppercase tracking-wider shadow-xl shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
          >
            <Play className="w-5 h-5 fill-stone-950" />
            <span>Start Game</span>
          </button>
        </div>
      </div>

      {/* Single Flat Control-Hint Line */}
      <div className="text-center text-xs text-stone-500 tracking-wide font-mono">
        Click / Space Roll · Click Pawn Move · Drag Orbit · H Toggle Dock · Esc Pause
      </div>
    </div>
  );
};

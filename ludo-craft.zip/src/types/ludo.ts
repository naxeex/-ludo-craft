export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export type PlayerType = 'human' | 'ai';

export interface PlayerConfig {
  color: PlayerColor;
  name: string;
  type: PlayerType;
  active: boolean;
}

export interface Token {
  id: number; // 0..3 for each color
  color: PlayerColor;
  step: number; // -1 = Yard, 0..51 = Main Track (color-relative or absolute), 52..56 = Home Column, 57 = Home / Finished
  boardIndex: number; // -1 if not on track, 0..51 on main track, 100+ for home stretch
  isFinished: boolean;
  isInYard: boolean;
}

export type GamePhase =
  | 'title'
  | 'waiting_for_roll'
  | 'rolling'
  | 'selecting_token'
  | 'moving'
  | 'ai_thinking'
  | 'game_over';

export type BoardTheme = 'classic' | 'royal' | 'neon' | 'marble';

export type CameraPreset = 'perspective' | 'topdown' | 'isometric';

export interface MoveOption {
  tokenId: number;
  fromStep: number;
  toStep: number;
  isCapture: boolean;
  isEntering: boolean;
  isGoal: boolean;
}

export interface GameHistoryEntry {
  id: string;
  color: PlayerColor;
  text: string;
  timestamp: number;
}

export interface PlayerStats {
  color: PlayerColor;
  tokensHome: number;
  tokensOnTrack: number;
  tokensInYard: number;
  kills: number;
  deaths: number;
}

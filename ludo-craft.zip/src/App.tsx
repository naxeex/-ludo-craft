/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  PlayerColor,
  Token,
  PlayerConfig,
  GamePhase,
  BoardTheme,
  CameraPreset,
  MoveOption,
  PlayerStats,
} from './types/ludo';
import {
  getValidMoves,
  chooseAIMove,
  PLAYERS_ORDER,
  SAFE_PERIMETER_INDICES,
  getPerimeterIndex,
  GOAL_STEP,
} from './utils/ludoRules';
import { LudoScene } from './3d/LudoScene';
import { TitleScreen } from './components/TitleScreen';
import { TurnBanner } from './components/TurnBanner';
import { PlayerCards } from './components/PlayerCards';
import { ControlDock } from './components/ControlDock';
import { VictoryModal } from './components/VictoryModal';
import { RulesModal } from './components/RulesModal';
import { sounds } from './audio/soundEffects';

function createInitialTokens(): Token[] {
  const tokens: Token[] = [];
  PLAYERS_ORDER.forEach((color) => {
    for (let id = 0; id < 4; id++) {
      tokens.push({
        id,
        color,
        step: -1,
        boardIndex: -1,
        isFinished: false,
        isInYard: true,
      });
    }
  });
  return tokens;
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<LudoScene | null>(null);

  // Game Configuration State
  const [theme, setTheme] = useState<BoardTheme>('royal');
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('perspective');
  const [isMuted, setIsMuted] = useState<boolean>(sounds.getMuted());
  const [isRulesOpen, setIsRulesOpen] = useState(false);

  // Game Loop State
  const [gamePhase, setGamePhase] = useState<GamePhase>('title');
  const [players, setPlayers] = useState<PlayerConfig[]>([
    { color: 'red', name: 'Player 1', type: 'human', active: true },
    { color: 'green', name: 'AI Green', type: 'ai', active: true },
    { color: 'yellow', name: 'AI Yellow', type: 'ai', active: true },
    { color: 'blue', name: 'AI Blue', type: 'ai', active: true },
  ]);
  const [activePlayerIndex, setActivePlayerIndex] = useState(0);
  const [tokens, setTokens] = useState<Token[]>(createInitialTokens);
  const [diceRoll, setDiceRoll] = useState<number | null>(null);
  const [consecutiveSixes, setConsecutiveSixes] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [validMoves, setValidMoves] = useState<MoveOption[]>([]);
  const [winner, setWinner] = useState<PlayerConfig | null>(null);

  // Statistics
  const [stats, setStats] = useState<Map<PlayerColor, PlayerStats>>(() => {
    const map = new Map<PlayerColor, PlayerStats>();
    PLAYERS_ORDER.forEach((c) => {
      map.set(c, {
        color: c,
        tokensHome: 0,
        tokensOnTrack: 0,
        tokensInYard: 4,
        kills: 0,
        deaths: 0,
      });
    });
    return map;
  });

  // Mutable refs to prevent stale closures in async callbacks
  const activePlayers = players.filter((p) => p.active);
  const activePlayer = activePlayers[activePlayerIndex] || activePlayers[0] || players[0];

  const gameStateRef = useRef({
    gamePhase,
    activePlayer,
    tokens,
    diceRoll,
    consecutiveSixes,
    validMoves,
    activePlayers,
    activePlayerIndex,
  });

  useEffect(() => {
    gameStateRef.current = {
      gamePhase,
      activePlayer,
      tokens,
      diceRoll,
      consecutiveSixes,
      validMoves,
      activePlayers,
      activePlayerIndex,
    };
  }, [
    gamePhase,
    activePlayer,
    tokens,
    diceRoll,
    consecutiveSixes,
    validMoves,
    activePlayers,
    activePlayerIndex,
  ]);

  // Handle Token Click (from 3D scene or UI dock)
  const handleSelectToken = useCallback(
    (tokenId: number) => {
      const { gamePhase: currentPhase, validMoves: moves, activePlayer: currPlayer, tokens: currentTokens } = gameStateRef.current;
      if (currentPhase !== 'selecting_token') return;

      const move = moves.find((m) => m.tokenId === tokenId);
      if (!move) return;

      executeMove(move, currPlayer, currentTokens);
    },
    []
  );

  // Handle 3D Dice Click
  const handleDiceClick = useCallback(() => {
    const { gamePhase: currentPhase, activePlayer: currPlayer } = gameStateRef.current;
    if (currentPhase === 'waiting_for_roll' && currPlayer.type === 'human') {
      triggerDiceRoll();
    }
  }, []);

  // Initialize Three.js Scene once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new LudoScene(mountRef.current, {
      onDiceClicked: () => {
        handleDiceClick();
      },
      onTokenClicked: (color, tokenId) => {
        const { activePlayer: currPlayer } = gameStateRef.current;
        if (color === currPlayer.color) {
          handleSelectToken(tokenId);
        }
      },
      onMoveComplete: () => {
        // Handled per animation
      },
    });

    sceneRef.current = scene;

    return () => {
      scene.dispose();
      sceneRef.current = null;
    };
  }, [handleDiceClick, handleSelectToken]);

  // Sync token positions to Three.js whenever tokens update
  useEffect(() => {
    if (sceneRef.current) {
      sceneRef.current.updateTokensState(tokens);
    }
  }, [tokens]);

  // Keyboard shortcut listener for Space (Roll) and Escape (Pause/Menu)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        const { gamePhase: curPhase, activePlayer: curPlayer } = gameStateRef.current;
        if (curPhase === 'waiting_for_roll' && curPlayer.type === 'human') {
          e.preventDefault();
          triggerDiceRoll();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Roll Dice Function
  const triggerDiceRoll = () => {
    if (!sceneRef.current) return;
    setGamePhase('rolling');
    setStatusMessage('Rolling dice...');

    // Generate random roll 1..6
    const roll = Math.floor(Math.random() * 6) + 1;
    setDiceRoll(roll);

    sceneRef.current.rollDice(roll, () => {
      handleDiceSettled(roll);
    });
  };

  // When Dice lands and settles
  const handleDiceSettled = (roll: number) => {
    const {
      activePlayer: currPlayer,
      tokens: currentTokens,
      consecutiveSixes: prevSixes,
    } = gameStateRef.current;

    let newSixes = prevSixes;
    if (roll === 6) {
      newSixes += 1;
      setConsecutiveSixes(newSixes);
    } else {
      newSixes = 0;
      setConsecutiveSixes(0);
    }

    // Check three consecutive sixes rule
    if (newSixes === 3) {
      setStatusMessage('Three consecutive 6s! Turn forfeited.');
      setTimeout(() => {
        passTurn();
      }, 1400);
      return;
    }

    // Calculate valid moves
    const moves = getValidMoves(currPlayer.color, currentTokens, currentTokens, roll);
    setValidMoves(moves);

    if (moves.length === 0) {
      setStatusMessage(`Rolled a ${roll}. No valid moves!`);
      setTimeout(() => {
        passTurn();
      }, 1200);
      return;
    }

    // Highlight moves in 3D
    if (sceneRef.current) {
      sceneRef.current.setSelectableTokens(moves, currPlayer.color);
    }

    if (currPlayer.type === 'ai') {
      setGamePhase('ai_thinking');
      setStatusMessage(`${currPlayer.name} is choosing a move...`);

      setTimeout(() => {
        const chosen = chooseAIMove(moves, currentTokens, currentTokens);
        if (chosen) {
          executeMove(chosen, currPlayer, currentTokens);
        } else {
          passTurn();
        }
      }, 700);
    } else {
      // Human turn
      setGamePhase('selecting_token');
      setStatusMessage(
        roll === 6
          ? 'Rolled a 6! Choose a token to move or enter.'
          : `Rolled a ${roll}. Choose a token to advance.`
      );
    }
  };

  // Execute Move Animation & State Transition
  const executeMove = (
    move: MoveOption,
    currPlayer: PlayerConfig,
    currentTokens: Token[]
  ) => {
    if (!sceneRef.current) return;

    setGamePhase('moving');
    // Clear 3D selection highlights
    sceneRef.current.setSelectableTokens([], currPlayer.color);

    const isGoal = move.toStep === GOAL_STEP;
    let isCapture = false;
    let capturedTokenKey: { color: PlayerColor; id: number } | null = null;

    // Check if target step lands on an opponent's token
    if (move.toStep <= 50) {
      const targetPerimeter = getPerimeterIndex(currPlayer.color, move.toStep);
      if (!SAFE_PERIMETER_INDICES.has(targetPerimeter)) {
        const opponent = currentTokens.find(
          (t) =>
            t.color !== currPlayer.color &&
            !t.isFinished &&
            getPerimeterIndex(t.color, t.step) === targetPerimeter
        );
        if (opponent) {
          isCapture = true;
          capturedTokenKey = { color: opponent.color, id: opponent.id };
        }
      }
    }

    // Run 3D sequential hopping animation
    sceneRef.current.animatePawnMove(
      currPlayer.color,
      move.tokenId,
      move.fromStep,
      move.toStep,
      isCapture,
      isGoal,
      () => {
        // Animation finished: update tokens state
        setTokens((prev) => {
          const next = prev.map((t) => {
            if (t.color === currPlayer.color && t.id === move.tokenId) {
              const reachedGoal = move.toStep === GOAL_STEP;
              return {
                ...t,
                step: move.toStep,
                isInYard: false,
                isFinished: reachedGoal,
              };
            }
            // If an opponent piece was captured, send it back to yard
            if (
              capturedTokenKey &&
              t.color === capturedTokenKey.color &&
              t.id === capturedTokenKey.id
            ) {
              return {
                ...t,
                step: -1,
                isInYard: true,
                isFinished: false,
              };
            }
            return t;
          });

          // Check Win Condition
          const playerTokens = next.filter((t) => t.color === currPlayer.color);
          const allHome = playerTokens.every((t) => t.isFinished);

          if (allHome) {
            setWinner(currPlayer);
            setGamePhase('game_over');
            return next;
          }

          // Update stats
          setStats((prevStats) => {
            const nextMap = new Map(prevStats);
            const pStat = nextMap.get(currPlayer.color);
            if (pStat) {
              pStat.tokensHome = playerTokens.filter((t) => t.isFinished).length;
              pStat.tokensInYard = playerTokens.filter((t) => t.isInYard).length;
              pStat.tokensOnTrack = 4 - pStat.tokensHome - pStat.tokensInYard;
              if (isCapture) pStat.kills += 1;
            }
            if (capturedTokenKey) {
              const oppStat = nextMap.get(capturedTokenKey.color);
              if (oppStat) {
                oppStat.deaths += 1;
                oppStat.tokensInYard += 1;
                oppStat.tokensOnTrack = Math.max(0, oppStat.tokensOnTrack - 1);
              }
            }
            return nextMap;
          });

          // Determine bonus roll or next turn
          const rollValue = gameStateRef.current.diceRoll;
          const earnsBonusRoll = rollValue === 6 || isCapture || isGoal;

          if (earnsBonusRoll) {
            let bonusMsg = 'Bonus roll granted!';
            if (rollValue === 6) bonusMsg = 'Rolled a 6! Roll again!';
            if (isCapture) bonusMsg = 'Capture! Extra roll awarded!';
            if (isGoal) bonusMsg = 'Token reached Goal! Extra roll!';

            setStatusMessage(bonusMsg);
            setGamePhase('waiting_for_roll');

            // If AI, trigger next roll after brief delay
            if (currPlayer.type === 'ai') {
              setTimeout(() => {
                triggerDiceRoll();
              }, 800);
            }
          } else {
            // Next player's turn
            passTurn();
          }

          return next;
        });
      }
    );
  };

  // Pass Turn to next active player
  const passTurn = () => {
    const { activePlayers: list, activePlayerIndex: currentIndex } = gameStateRef.current;
    const nextIndex = (currentIndex + 1) % list.length;
    const nextPlayer = list[nextIndex];

    setActivePlayerIndex(nextIndex);
    setDiceRoll(null);
    setConsecutiveSixes(0);
    setValidMoves([]);

    setGamePhase('waiting_for_roll');
    setStatusMessage(
      nextPlayer.type === 'human'
        ? `${nextPlayer.name}'s turn. Roll the dice!`
        : `${nextPlayer.name}'s turn...`
    );

    // If next player is AI, schedule automated roll
    if (nextPlayer.type === 'ai') {
      setGamePhase('ai_thinking');
      setTimeout(() => {
        triggerDiceRoll();
      }, 700);
    }
  };

  // Start Game from Title Screen
  const handleStartGame = (configuredPlayers: PlayerConfig[], chosenTheme: BoardTheme) => {
    setPlayers(configuredPlayers);
    setTheme(chosenTheme);
    setTokens(createInitialTokens());
    setActivePlayerIndex(0);
    setDiceRoll(null);
    setConsecutiveSixes(0);
    setWinner(null);

    if (sceneRef.current) {
      sceneRef.current.buildBoard(chosenTheme);
      sceneRef.current.setCameraPreset('perspective');
    }

    const firstActive = configuredPlayers.find((p) => p.active) || configuredPlayers[0];
    setStatusMessage(
      firstActive.type === 'human'
        ? `${firstActive.name}'s turn! Roll the dice.`
        : `${firstActive.name} is preparing to roll...`
    );

    setGamePhase('waiting_for_roll');

    if (firstActive.type === 'ai') {
      setTimeout(() => {
        triggerDiceRoll();
      }, 900);
    }
  };

  // Camera preset handler
  const handleCameraChange = (preset: CameraPreset) => {
    setCameraPreset(preset);
    if (sceneRef.current) {
      sceneRef.current.setCameraPreset(preset);
    }
  };

  // Theme switch handler
  const handleThemeChange = (newTheme: BoardTheme) => {
    setTheme(newTheme);
    if (sceneRef.current) {
      sceneRef.current.buildBoard(newTheme);
    }
  };

  // Audio mute handler
  const handleToggleMute = () => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  // Restart handler
  const handleRestart = () => {
    setGamePhase('title');
    setTokens(createInitialTokens());
    setDiceRoll(null);
    setWinner(null);
    if (sceneRef.current) {
      sceneRef.current.setSelectableTokens([], 'red');
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-stone-950 select-none">
      {/* 3D WebGL Canvas Mount Container */}
      <div ref={mountRef} className="absolute inset-0 z-0 w-full h-full cursor-grab" />

      {/* Title Screen Overlay */}
      {gamePhase === 'title' && (
        <TitleScreen
          onStartGame={handleStartGame}
          onOpenRules={() => setIsRulesOpen(true)}
          currentTheme={theme}
          onThemeChange={handleThemeChange}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* In-Game HUD: Top Status Banner */}
      {gamePhase !== 'title' && (
        <TurnBanner
          activePlayer={activePlayer}
          gamePhase={gamePhase}
          diceRoll={diceRoll}
          message={statusMessage}
          consecutiveSixes={consecutiveSixes}
        />
      )}

      {/* In-Game HUD: Perimeter Corner Status Clusters */}
      {gamePhase !== 'title' && (
        <PlayerCards
          players={players}
          tokens={tokens}
          activeColor={activePlayer.color}
        />
      )}

      {/* In-Game HUD: Collapsible Bottom Control Dock */}
      {gamePhase !== 'title' && (
        <ControlDock
          activePlayer={activePlayer}
          gamePhase={gamePhase}
          onRollDice={triggerDiceRoll}
          validMoves={validMoves}
          onSelectToken={handleSelectToken}
          currentCamera={cameraPreset}
          onCameraChange={handleCameraChange}
          currentTheme={theme}
          onThemeChange={handleThemeChange}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onOpenRules={() => setIsRulesOpen(true)}
          onRestart={handleRestart}
        />
      )}

      {/* Victory Celebration Modal */}
      {gamePhase === 'game_over' && winner && (
        <VictoryModal
          winner={winner}
          players={activePlayers}
          stats={stats}
          onPlayAgain={() => handleStartGame(players, theme)}
          onMainMenu={handleRestart}
        />
      )}

      {/* Rules Cheatsheet Modal */}
      <RulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />
    </div>
  );
}

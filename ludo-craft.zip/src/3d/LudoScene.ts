import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  PlayerColor,
  Token,
  BoardTheme,
  CameraPreset,
  MoveOption,
} from '../types/ludo';
import {
  getCoordinatesForStep,
  PERIMETER_PATH,
  COLOR_START_INDICES,
  GOAL_STEP,
  COLOR_HEX,
} from '../utils/ludoRules';
import { createProceduralBoardTexture } from './boardTexture';
import {
  createPawnMesh,
  createDiceMesh,
  getDiceTargetRotation,
  createContactShadow,
} from './models';
import { sounds } from '../audio/soundEffects';

// Reusable vectors outside loop to enforce zero GC
const _vec3 = new THREE.Vector3();
const _targetPos = new THREE.Vector3();

export interface LudoSceneCallbacks {
  onDiceClicked: () => void;
  onTokenClicked: (color: PlayerColor, tokenId: number) => void;
  onMoveComplete: () => void;
}

export class LudoScene {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private controls: OrbitControls;
  private callbacks: LudoSceneCallbacks;

  // Board & Meshes
  private boardMesh!: THREE.Mesh;
  private boardTopMesh!: THREE.Mesh;
  private boardTexture!: THREE.CanvasTexture;
  private tableMesh!: THREE.Mesh;

  // Pawns: color -> tokenId -> THREE.Group
  private pawns: Map<string, THREE.Group> = new Map();
  // Tokens data
  private tokensData: Token[] = [];
  private selectableTokens: Set<string> = new Set();

  // Dice
  private diceGroup!: THREE.Group;
  private diceShadow!: THREE.Mesh;
  private isDiceRolling = false;
  private diceRollStartTime = 0;
  private diceRollDuration = 0.9;
  private diceTargetFace = 1;
  private diceStartRot = new THREE.Euler();
  private diceTargetRot = new THREE.Euler();

  // Piece hopping animation
  private activeHoppingPawn: {
    group: THREE.Group;
    path: THREE.Vector3[];
    currentStepIndex: number;
    stepProgress: number; // 0..1
    stepDuration: number;
    color: PlayerColor;
    tokenId: number;
    isCapture: boolean;
    isGoal: boolean;
  } | null = null;

  // Camera smooth damp
  private targetCameraPos = new THREE.Vector3(0, 18, 14);
  private targetCameraLookAt = new THREE.Vector3(0, 0, 0);

  // Raycaster & Interactivity
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private hoveredObject: THREE.Object3D | null = null;

  // Particle System
  private particleGroup = new THREE.Group();
  private particles: {
    mesh: THREE.Mesh;
    velocity: THREE.Vector3;
    life: number;
    maxLife: number;
  }[] = [];

  // Loop control
  private animFrameId: number | null = null;
  private clock = new THREE.Clock();
  private isDisposed = false;
  private currentTheme: BoardTheme = 'royal';

  constructor(container: HTMLElement, callbacks: LudoSceneCallbacks) {
    this.container = container;
    this.callbacks = callbacks;

    // 1. Scene setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0f1118);
    this.scene.fog = new THREE.FogExp2(0x0f1118, 0.015);

    // 2. Camera setup
    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(40, aspect, 0.1, 100);
    this.camera.position.set(0, 18, 14);

    // 3. Renderer setup
    const isHeadless =
      navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent);
    this.renderer = new THREE.WebGLRenderer({ antialias: !isHeadless, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(
      isHeadless ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !isHeadless;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 4. Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.05; // Never dip below ground
    this.controls.minDistance = 6;
    this.controls.maxDistance = 35;
    this.controls.target.set(0, 0, 0);

    // 5. Procedural Room Environment for PBR Reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    pmremGenerator.dispose();

    // 6. Lighting Rig
    this.setupLighting();

    // 7. Build Environment, Board, Pawns, Dice
    this.buildTableAndRoom();
    this.buildBoard('royal');
    this.buildPawns();
    this.buildDice();
    this.scene.add(this.particleGroup);

    // 8. Event listeners
    this.renderer.domElement.addEventListener('pointermove', this.onPointerMove);
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('resize', this.onWindowResize);

    // 9. Prewarm shaders
    this.renderer.compile(this.scene, this.camera);

    // 10. Start render loop
    this.animate();
  }

  private setupLighting(): void {
    // Warm Key Light with PCF soft shadows
    const keyLight = new THREE.DirectionalLight(0xfff7ed, 2.2);
    keyLight.position.set(10, 22, 12);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 5;
    keyLight.shadow.camera.far = 45;
    const d = 12;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    this.scene.add(keyLight);

    // Cool Fill Light from opposite quadrant
    const fillLight = new THREE.DirectionalLight(0xdbeafe, 0.8);
    fillLight.position.set(-12, 14, -10);
    this.scene.add(fillLight);

    // Sky/Ground Hemisphere Light
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x1c1917, 0.7);
    this.scene.add(hemiLight);
  }

  private buildTableAndRoom(): void {
    // Elegant Mahogany Game Table Surface
    const tableGeo = new THREE.CylinderGeometry(18, 19, 1.2, 48);
    const tableMat = new THREE.MeshStandardMaterial({
      color: 0x180d07,
      roughness: 0.35,
      metalness: 0.1,
    });
    this.tableMesh = new THREE.Mesh(tableGeo, tableMat);
    this.tableMesh.position.y = -0.6;
    this.tableMesh.receiveShadow = true;
    this.scene.add(this.tableMesh);

    // Luxury Table Rim Trim ring
    const rimGeo = new THREE.TorusGeometry(18.05, 0.15, 16, 64);
    const rimMat = new THREE.MeshStandardMaterial({
      color: 0xc5a059,
      metalness: 0.85,
      roughness: 0.2,
    });
    const rimMesh = new THREE.Mesh(rimGeo, rimMat);
    rimMesh.rotation.x = Math.PI / 2;
    rimMesh.position.y = 0.0;
    this.scene.add(rimMesh);
  }

  public buildBoard(theme: BoardTheme): void {
    this.currentTheme = theme;
    if (this.boardMesh) {
      this.scene.remove(this.boardMesh);
      if (this.boardMesh.geometry) this.boardMesh.geometry.dispose();
    }
    if (this.boardTopMesh) {
      this.scene.remove(this.boardTopMesh);
      if (this.boardTopMesh.geometry) this.boardTopMesh.geometry.dispose();
    }

    const boardSize = 13.5;
    const boardHeight = 0.5;

    // Wood Base Block with beveled edges
    const baseGeo = new THREE.BoxGeometry(boardSize, boardHeight, boardSize);
    const baseColor =
      theme === 'royal'
        ? 0x241209
        : theme === 'neon'
        ? 0x0a0c16
        : theme === 'marble'
        ? 0xd1d5db
        : 0x3e2723;

    const baseMat = new THREE.MeshStandardMaterial({
      color: baseColor,
      roughness: theme === 'marble' ? 0.2 : 0.4,
      metalness: theme === 'neon' ? 0.3 : 0.15,
    });

    this.boardMesh = new THREE.Mesh(baseGeo, baseMat);
    this.boardMesh.position.y = boardHeight / 2;
    this.boardMesh.castShadow = true;
    this.boardMesh.receiveShadow = true;
    this.scene.add(this.boardMesh);

    // Gold / Metal Beveled Border Inlay
    const cornerMat = new THREE.MeshStandardMaterial({
      color: theme === 'royal' ? 0xf59e0b : theme === 'neon' ? 0x60a5fa : 0xd4af37,
      metalness: 0.9,
      roughness: 0.15,
    });

    // 4 Corner Brackets
    const cornerOffsets = [
      [-boardSize / 2 + 0.4, -boardSize / 2 + 0.4],
      [boardSize / 2 - 0.4, -boardSize / 2 + 0.4],
      [boardSize / 2 - 0.4, boardSize / 2 - 0.4],
      [-boardSize / 2 + 0.4, boardSize / 2 - 0.4],
    ];
    cornerOffsets.forEach(([cx, cz]) => {
      const bracketGeo = new THREE.BoxGeometry(0.8, boardHeight + 0.02, 0.8);
      const bracket = new THREE.Mesh(bracketGeo, cornerMat);
      bracket.position.set(cx, boardHeight / 2, cz);
      this.boardMesh.add(bracket);
    });

    // Board Surface Texture Plane (offset slightly to avoid z-fighting)
    const playAreaSize = boardSize - 0.6;
    const topGeo = new THREE.PlaneGeometry(playAreaSize, playAreaSize);
    this.boardTexture = createProceduralBoardTexture(theme, this.renderer.capabilities.getMaxAnisotropy());

    const topMat = new THREE.MeshStandardMaterial({
      map: this.boardTexture,
      roughness: theme === 'royal' ? 0.3 : theme === 'marble' ? 0.15 : 0.25,
      metalness: theme === 'neon' ? 0.25 : 0.05,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });

    this.boardTopMesh = new THREE.Mesh(topGeo, topMat);
    this.boardTopMesh.rotation.x = -Math.PI / 2;
    this.boardTopMesh.position.y = boardHeight + 0.005;
    this.boardTopMesh.receiveShadow = true;
    this.scene.add(this.boardTopMesh);

    // Soft Contact Shadow underneath entire board
    const boardShadow = createContactShadow(boardSize * 0.58, 0.5);
    boardShadow.position.y = 0.002;
    this.scene.add(boardShadow);
  }

  private buildPawns(): void {
    const colors: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];
    colors.forEach((c) => {
      for (let i = 0; i < 4; i++) {
        const key = `${c}_${i}`;
        const pawnGroup = createPawnMesh(c, this.currentTheme);
        pawnGroup.userData = { color: c, tokenId: i, isPawn: true };

        // Position in initial yard
        const coord = getCoordinatesForStep(c, i, -1);
        const worldPos = this.gridToWorld(coord.row, coord.col);
        pawnGroup.position.set(worldPos.x, worldPos.y, worldPos.z);

        this.scene.add(pawnGroup);
        this.pawns.set(key, pawnGroup);
      }
    });
  }

  private buildDice(): void {
    this.diceGroup = createDiceMesh();
    this.diceGroup.userData = { isDice: true };

    // Place dice in a convenient tray area near the board
    this.diceGroup.position.set(7.8, 0.6, 7.2);
    this.diceGroup.scale.set(0.9, 0.9, 0.9);

    // Contact shadow beneath dice
    this.diceShadow = createContactShadow(0.8, 0.5);
    this.diceShadow.position.set(7.8, 0.006, 7.2);

    this.scene.add(this.diceGroup);
    this.scene.add(this.diceShadow);
  }

  /**
   * Converts 15x15 Ludo grid coordinates (0..14) to 3D world space (X, Y, Z).
   */
  public gridToWorld(row: number, col: number): THREE.Vector3 {
    const playAreaSize = 13.5 - 0.6; // 12.9
    const cellSize = playAreaSize / 15; // ~0.86
    const half = playAreaSize / 2;

    const x = col * cellSize - half + cellSize / 2;
    const z = row * cellSize - half + cellSize / 2;
    const y = 0.51; // Sits flush on top of board

    return new THREE.Vector3(x, y, z);
  }

  /**
   * Updates state of all tokens from the React game state.
   */
  public updateTokensState(tokens: Token[]): void {
    this.tokensData = tokens;

    tokens.forEach((token) => {
      const key = `${token.color}_${token.id}`;
      const pawnGroup = this.pawns.get(key);
      if (!pawnGroup) return;

      // Only teleport if this pawn is not actively hopping
      if (
        this.activeHoppingPawn &&
        this.activeHoppingPawn.color === token.color &&
        this.activeHoppingPawn.tokenId === token.id
      ) {
        return;
      }

      const coord = getCoordinatesForStep(token.color, token.id, token.step);
      const target = this.gridToWorld(coord.row, coord.col);

      // Sinking in center goal if completed
      if (token.isFinished) {
        pawnGroup.position.set(target.x, target.y + 0.1, target.z);
        pawnGroup.scale.set(0.85, 0.85, 0.85);
      } else {
        pawnGroup.position.copy(target);
        pawnGroup.scale.set(1, 1, 1);
      }
    });
  }

  /**
   * Highlight selectable tokens with pulsating glow rings and gentle hover bounce.
   */
  public setSelectableTokens(options: MoveOption[], activeColor: PlayerColor): void {
    this.selectableTokens.clear();

    // Reset all pawns
    this.pawns.forEach((group) => {
      const ring = group.getObjectByName('selection_ring') as THREE.Mesh;
      if (ring) {
        (ring.material as THREE.MeshBasicMaterial).opacity = 0;
      }
    });

    options.forEach((opt) => {
      const key = `${activeColor}_${opt.tokenId}`;
      this.selectableTokens.add(key);

      const group = this.pawns.get(key);
      if (group) {
        const ring = group.getObjectByName('selection_ring') as THREE.Mesh;
        if (ring) {
          (ring.material as THREE.MeshBasicMaterial).opacity = 0.85;
          (ring.material as THREE.MeshBasicMaterial).color.setHex(0xfacc15); // Vibrant gold
        }
      }
    });
  }

  /**
   * Trigger 3D dice rolling animation and settle on target face.
   */
  public rollDice(targetValue: number, onSettled: () => void): void {
    if (this.isDiceRolling) return;

    this.isDiceRolling = true;
    this.diceTargetFace = targetValue;
    this.diceRollStartTime = this.clock.getElapsedTime();
    this.diceRollDuration = 0.85;

    this.diceStartRot.copy(this.diceGroup.rotation);
    const targetEuler = getDiceTargetRotation(targetValue);
    // Add multiple full spins (3 * 2PI) for dynamic tumble
    this.diceTargetRot.set(
      targetEuler.x + Math.PI * 6,
      targetEuler.y + Math.PI * 4,
      targetEuler.z + Math.PI * 4
    );

    sounds.playDiceRoll();

    // After animation ends, settle and callback
    setTimeout(() => {
      this.isDiceRolling = false;
      const finalEuler = getDiceTargetRotation(this.diceTargetFace);
      this.diceGroup.rotation.set(finalEuler.x, finalEuler.y, finalEuler.z);
      this.diceGroup.position.y = 0.6;
      sounds.playDiceSettle();
      onSettled();
    }, this.diceRollDuration * 1000);
  }

  /**
   * Start sequential hopping movement along tiles from fromStep to toStep.
   */
  public animatePawnMove(
    color: PlayerColor,
    tokenId: number,
    fromStep: number,
    toStep: number,
    isCapture: boolean,
    isGoal: boolean,
    onDone: () => void
  ): void {
    const key = `${color}_${tokenId}`;
    const group = this.pawns.get(key);
    if (!group) {
      onDone();
      return;
    }

    // Build step-by-step path coordinates
    const path: THREE.Vector3[] = [];

    if (fromStep === -1) {
      // Entering from yard to starting square
      const startCoord = getCoordinatesForStep(color, tokenId, -1);
      const endCoord = getCoordinatesForStep(color, tokenId, 0);
      path.push(this.gridToWorld(startCoord.row, startCoord.col));
      path.push(this.gridToWorld(endCoord.row, endCoord.col));
      sounds.playTokenEnter();
    } else {
      // Step by step progression
      for (let s = fromStep; s <= toStep; s++) {
        const coord = getCoordinatesForStep(color, tokenId, s);
        path.push(this.gridToWorld(coord.row, coord.col));
      }
    }

    this.activeHoppingPawn = {
      group,
      path,
      currentStepIndex: 0,
      stepProgress: 0,
      stepDuration: 0.16, // Hop speed per tile
      color,
      tokenId,
      isCapture,
      isGoal,
    };

    // Store completion handler
    const checkInterval = setInterval(() => {
      if (!this.activeHoppingPawn) {
        clearInterval(checkInterval);
        if (isCapture) {
          sounds.playCapture();
          this.spawnParticleBurst(group.position, 0xef4444);
        } else if (isGoal) {
          sounds.playHomeGoal();
          this.spawnParticleBurst(group.position, 0xf59e0b);
        }
        onDone();
      }
    }, 30);
  }

  /**
   * Spawns festive 3D particle bursts.
   */
  public spawnParticleBurst(position: THREE.Vector3, colorHex: number): void {
    const count = 30;
    const pGeo = new THREE.SphereGeometry(0.08, 8, 8);
    const pMat = new THREE.MeshBasicMaterial({ color: colorHex });

    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(pGeo, pMat);
      mesh.position.copy(position).add(new THREE.Vector3(0, 0.4, 0));

      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 4;
      const vy = 3 + Math.random() * 4;
      const velocity = new THREE.Vector3(
        Math.cos(angle) * speed,
        vy,
        Math.sin(angle) * speed
      );

      this.particleGroup.add(mesh);
      this.particles.push({
        mesh,
        velocity,
        life: 0,
        maxLife: 0.7 + Math.random() * 0.4,
      });
    }
  }

  /**
   * Smoothly transitions camera to standard presets.
   */
  public setCameraPreset(preset: CameraPreset): void {
    switch (preset) {
      case 'perspective':
        this.targetCameraPos.set(0, 16, 13);
        this.targetCameraLookAt.set(0, 0, 0);
        break;
      case 'topdown':
        this.targetCameraPos.set(0, 24, 0.01);
        this.targetCameraLookAt.set(0, 0, 0);
        break;
      case 'isometric':
        this.targetCameraPos.set(14, 18, 14);
        this.targetCameraLookAt.set(0, 0, 0);
        break;
    }
  }

  private onPointerMove = (e: MouseEvent): void => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointer, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    let foundInteractable: THREE.Object3D | null = null;

    for (const hit of intersects) {
      let curr: THREE.Object3D | null = hit.object;
      while (curr && curr !== this.scene) {
        if (curr.userData && (curr.userData.isDice || curr.userData.isPawn)) {
          foundInteractable = curr;
          break;
        }
        curr = curr.parent;
      }
      if (foundInteractable) break;
    }

    if (foundInteractable) {
      this.renderer.domElement.style.cursor = 'pointer';
    } else {
      this.renderer.domElement.style.cursor = 'grab';
    }

    this.hoveredObject = foundInteractable;
  };

  private onPointerDown = (e: MouseEvent): void => {
    // Only respond to primary left click
    if (e.button !== 0) return;

    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointer, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    for (const hit of intersects) {
      let curr: THREE.Object3D | null = hit.object;
      while (curr && curr !== this.scene) {
        if (curr.userData) {
          if (curr.userData.isDice) {
            this.callbacks.onDiceClicked();
            return;
          }
          if (curr.userData.isPawn) {
            const key = `${curr.userData.color}_${curr.userData.tokenId}`;
            if (this.selectableTokens.has(key)) {
              this.callbacks.onTokenClicked(
                curr.userData.color,
                curr.userData.tokenId
              );
              return;
            }
          }
        }
        curr = curr.parent;
      }
    }
  };

  private onWindowResize = (): void => {
    if (!this.container) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private animate = (): void => {
    if (this.isDisposed) return;
    this.animFrameId = requestAnimationFrame(this.animate);

    const delta = Math.min(this.clock.getDelta(), 0.05);
    const time = this.clock.getElapsedTime();

    // 1. Smooth Camera Damping towards target view preset
    this.camera.position.lerp(this.targetCameraPos, 1 - Math.exp(-4 * delta));
    this.controls.target.lerp(this.targetCameraLookAt, 1 - Math.exp(-4 * delta));
    this.controls.update();

    // 2. Dice Roll Kinematics
    if (this.isDiceRolling) {
      const elapsed = time - this.diceRollStartTime;
      const progress = Math.min(elapsed / this.diceRollDuration, 1.0);

      // Arc bounce in air
      const bounceHeight = Math.sin(progress * Math.PI) * 2.8;
      this.diceGroup.position.y = 0.6 + bounceHeight;

      // Rotation interpolation with spring deceleration
      const easeOut = 1 - Math.pow(1 - progress, 3);
      this.diceGroup.rotation.x = THREE.MathUtils.lerp(
        this.diceStartRot.x,
        this.diceTargetRot.x,
        easeOut
      );
      this.diceGroup.rotation.y = THREE.MathUtils.lerp(
        this.diceStartRot.y,
        this.diceTargetRot.y,
        easeOut
      );
      this.diceGroup.rotation.z = THREE.MathUtils.lerp(
        this.diceStartRot.z,
        this.diceTargetRot.z,
        easeOut
      );

      // Scale shadow with height
      const shadowScale = 1 - Math.sin(progress * Math.PI) * 0.4;
      this.diceShadow.scale.set(shadowScale, shadowScale, shadowScale);
    } else {
      // Gentle idle float on dice to invite interaction
      this.diceGroup.position.y = 0.6 + Math.sin(time * 2.5) * 0.05;
    }

    // 3. Piece Hopping Motion along exact track coordinates
    if (this.activeHoppingPawn) {
      const hop = this.activeHoppingPawn;
      hop.stepProgress += delta / hop.stepDuration;

      const p0 = hop.path[hop.currentStepIndex];
      const p1 = hop.path[hop.currentStepIndex + 1];

      if (p0 && p1) {
        const t = Math.min(hop.stepProgress, 1.0);
        // Parabolic arc for realistic hopping
        const hopArc = Math.sin(t * Math.PI) * 0.55;

        hop.group.position.x = THREE.MathUtils.lerp(p0.x, p1.x, t);
        hop.group.position.z = THREE.MathUtils.lerp(p0.z, p1.z, t);
        hop.group.position.y = THREE.MathUtils.lerp(p0.y, p1.y, t) + hopArc;

        if (hop.stepProgress >= 1.0) {
          hop.currentStepIndex++;
          hop.stepProgress = 0;
          sounds.playPawnStep(hop.currentStepIndex);

          // Finished all steps
          if (hop.currentStepIndex >= hop.path.length - 1) {
            hop.group.position.copy(hop.path[hop.path.length - 1]);
            this.activeHoppingPawn = null;
          }
        }
      } else {
        this.activeHoppingPawn = null;
      }
    }

    // 4. Selectable tokens pulsating halo and bounce
    this.selectableTokens.forEach((key) => {
      const group = this.pawns.get(key);
      if (group && (!this.activeHoppingPawn || this.activeHoppingPawn.group !== group)) {
        // Subtle vertical bounce
        const bounce = Math.abs(Math.sin(time * 4)) * 0.18;
        const ring = group.getObjectByName('selection_ring') as THREE.Mesh;
        if (ring) {
          const ringScale = 1.0 + Math.sin(time * 5) * 0.12;
          ring.scale.set(ringScale, ringScale, 1);
        }
      }
    });

    // 5. Update Particle Bursts
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += delta;
      if (p.life >= p.maxLife) {
        this.particleGroup.remove(p.mesh);
        p.mesh.geometry.dispose();
        this.particles.splice(i, 1);
      } else {
        p.velocity.y -= 9.8 * delta; // Gravity
        p.mesh.position.addScaledVector(p.velocity, delta);
        const scale = 1 - p.life / p.maxLife;
        p.mesh.scale.set(scale, scale, scale);
      }
    }

    this.renderer.render(this.scene, this.camera);
  };

  public dispose(): void {
    this.isDisposed = true;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    this.renderer.domElement.removeEventListener('pointermove', this.onPointerMove);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);

    this.controls.dispose();
    this.renderer.dispose();
    if (this.container.contains(this.renderer.domElement)) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}

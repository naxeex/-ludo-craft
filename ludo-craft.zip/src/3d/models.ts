import * as THREE from 'three';
import { PlayerColor, BoardTheme } from '../types/ludo';
import { COLOR_HEX } from '../utils/ludoRules';

/**
 * Creates a soft radial contact shadow texture and mesh.
 */
export function createContactShadow(radius = 0.45, opacity = 0.4): THREE.Mesh {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(
    size / 2,
    size / 2,
    0,
    size / 2,
    size / 2,
    size / 2
  );
  grad.addColorStop(0, `rgba(0, 0, 0, ${opacity})`);
  grad.addColorStop(0.5, `rgba(0, 0, 0, ${opacity * 0.5})`);
  grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;

  const geo = new THREE.PlaneGeometry(radius * 2, radius * 2);
  const mat = new THREE.MeshBasicMaterial({
    map: texture,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.005;
  mesh.renderOrder = 2;
  return mesh;
}

/**
 * Creates a composite 5-part procedural Ludo Pawn (THREE.Group)
 * adhering to the Three.js skill multi-part model guidelines.
 */
export function createPawnMesh(color: PlayerColor, theme: BoardTheme): THREE.Group {
  const pawnGroup = new THREE.Group();
  pawnGroup.name = `pawn_${color}`;

  const colorConfig = COLOR_HEX[color];
  const mainColor = colorConfig.hexNum;

  // Primary Silhouette Materials:
  // Body: rich lacquer with physical clearcoat
  const bodyMat = new THREE.MeshPhysicalMaterial({
    color: mainColor,
    metalness: theme === 'neon' ? 0.3 : 0.08,
    roughness: theme === 'royal' ? 0.25 : 0.18,
    clearcoat: 0.9,
    clearcoatRoughness: 0.1,
  });

  // Secondary Read Material:
  // Burnished Gold / Chrome accent collar (high metalness, low roughness)
  const collarMat = new THREE.MeshStandardMaterial({
    color: theme === 'royal' ? 0xf59e0b : theme === 'neon' ? 0x93c5fd : 0xd4af37,
    metalness: 0.92,
    roughness: 0.15,
  });

  // Top Accent Gemstone:
  const gemMat = new THREE.MeshPhysicalMaterial({
    color: colorConfig.hexNum,
    metalness: 0.1,
    roughness: 0.05,
    transmission: 0.6,
    thickness: 0.8,
    clearcoat: 1.0,
  });

  // Part 1: Weighted Flared Base (Cylinder with beveled step)
  const baseGeo = new THREE.CylinderGeometry(0.32, 0.4, 0.15, 24);
  const baseMesh = new THREE.Mesh(baseGeo, bodyMat);
  baseMesh.position.y = 0.075;
  baseMesh.castShadow = true;
  baseMesh.receiveShadow = true;
  pawnGroup.add(baseMesh);

  // Part 2: Lower Pedestal Ring
  const lowerRingGeo = new THREE.TorusGeometry(0.33, 0.04, 12, 24);
  const lowerRing = new THREE.Mesh(lowerRingGeo, collarMat);
  lowerRing.rotation.x = Math.PI / 2;
  lowerRing.position.y = 0.13;
  lowerRing.castShadow = true;
  pawnGroup.add(lowerRing);

  // Part 3: Tapered Elegant Stem (Lathe / Waist)
  const waistPoints: THREE.Vector2[] = [];
  waistPoints.push(new THREE.Vector2(0.28, 0.15));
  waistPoints.push(new THREE.Vector2(0.24, 0.3));
  waistPoints.push(new THREE.Vector2(0.18, 0.48));
  waistPoints.push(new THREE.Vector2(0.14, 0.65));
  waistPoints.push(new THREE.Vector2(0.18, 0.72));
  const waistGeo = new THREE.LatheGeometry(waistPoints, 24);
  const waistMesh = new THREE.Mesh(waistGeo, bodyMat);
  waistMesh.castShadow = true;
  waistMesh.receiveShadow = true;
  pawnGroup.add(waistMesh);

  // Part 4: Royal Golden Neck Ring
  const neckRingGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.05, 24);
  const neckRing = new THREE.Mesh(neckRingGeo, collarMat);
  neckRing.position.y = 0.73;
  neckRing.castShadow = true;
  pawnGroup.add(neckRing);

  // Part 5: Crown Head Sphere
  const headGeo = new THREE.SphereGeometry(0.26, 24, 20);
  const headMesh = new THREE.Mesh(headGeo, bodyMat);
  headMesh.position.y = 0.96;
  headMesh.castShadow = true;
  headMesh.receiveShadow = true;
  pawnGroup.add(headMesh);

  // Part 6: Gem Finial on Top
  const finialGeo = new THREE.SphereGeometry(0.09, 16, 16);
  const finialMesh = new THREE.Mesh(finialGeo, gemMat);
  finialMesh.position.y = 1.25;
  finialMesh.castShadow = true;
  pawnGroup.add(finialMesh);

  // Contact Shadow Plane (grounded flush with bottom)
  const shadow = createContactShadow(0.48, 0.45);
  pawnGroup.add(shadow);

  // Selection Glow Ring (initially invisible)
  const ringGeo = new THREE.RingGeometry(0.42, 0.54, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const selectionRing = new THREE.Mesh(ringGeo, ringMat);
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.015;
  selectionRing.name = 'selection_ring';
  pawnGroup.add(selectionRing);

  return pawnGroup;
}

/**
 * Creates a composite 3D Dice with chamfered edges and 21 recessed pips.
 */
export function createDiceMesh(): THREE.Group {
  const diceGroup = new THREE.Group();
  diceGroup.name = 'interactive_dice';

  const size = 1.2;

  // Dice ivory/lacquer material
  const diceMat = new THREE.MeshPhysicalMaterial({
    color: 0xfaf8f5,
    roughness: 0.15,
    metalness: 0.02,
    clearcoat: 0.8,
    clearcoatRoughness: 0.1,
  });

  // Pip material: deep obsidian with slight gloss
  const pipMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.3,
    metalness: 0.1,
  });

  // Red pip material for the #1 center ace pip
  const acePipMat = new THREE.MeshStandardMaterial({
    color: 0xdc2626,
    roughness: 0.25,
    metalness: 0.1,
  });

  // Die main body: rounded box
  const boxGeo = new THREE.BoxGeometry(size, size, size, 4, 4, 4);
  // Round vertices slightly for soft chamfer
  const pos = boxGeo.attributes.position;
  const tempVec = new THREE.Vector3();
  const radius = size * 0.5;
  for (let i = 0; i < pos.count; i++) {
    tempVec.fromBufferAttribute(pos, i);
    // Soft spherical blend on corners
    const dist = tempVec.length();
    if (dist > radius * 1.1) {
      tempVec.normalize().multiplyScalar(radius * 1.15);
      pos.setXYZ(i, tempVec.x, tempVec.y, tempVec.z);
    }
  }
  boxGeo.computeVertexNormals();

  const boxMesh = new THREE.Mesh(boxGeo, diceMat);
  boxMesh.castShadow = true;
  boxMesh.receiveShadow = true;
  diceGroup.add(boxMesh);

  // Helper to add a pip cylinder
  const half = size / 2;
  const pipRadius = 0.09;
  const pipDepth = 0.02;
  const pipGeo = new THREE.CylinderGeometry(pipRadius, pipRadius, pipDepth, 16);

  const addPip = (
    pos: [number, number, number],
    rot: [number, number, number],
    material = pipMat
  ) => {
    const pip = new THREE.Mesh(pipGeo, material);
    pip.position.set(...pos);
    pip.rotation.set(...rot);
    diceGroup.add(pip);
  };

  const o = 0.28; // Pip offset from center
  const surf = half + 0.005;

  // Face 1: Top (+Y) -> Red Ace Pip
  addPip([0, surf, 0], [0, 0, 0], acePipMat);

  // Face 6: Bottom (-Y) -> 6 Pips
  [-o, o].forEach((x) => {
    [-o, 0, o].forEach((z) => {
      addPip([x, -surf, z], [0, 0, 0]);
    });
  });

  // Face 2: Front (+Z) -> 2 Pips
  addPip([-o, -o, surf], [Math.PI / 2, 0, 0]);
  addPip([o, o, surf], [Math.PI / 2, 0, 0]);

  // Face 5: Back (-Z) -> 5 Pips
  addPip([0, 0, -surf], [Math.PI / 2, 0, 0]);
  addPip([-o, -o, -surf], [Math.PI / 2, 0, 0]);
  addPip([o, -o, -surf], [Math.PI / 2, 0, 0]);
  addPip([-o, o, -surf], [Math.PI / 2, 0, 0]);
  addPip([o, o, -surf], [Math.PI / 2, 0, 0]);

  // Face 3: Right (+X) -> 3 Pips
  addPip([surf, -o, -o], [0, 0, Math.PI / 2]);
  addPip([surf, 0, 0], [0, 0, Math.PI / 2]);
  addPip([surf, o, o], [0, 0, Math.PI / 2]);

  // Face 4: Left (-X) -> 4 Pips
  addPip([-surf, -o, -o], [0, 0, Math.PI / 2]);
  addPip([-surf, -o, o], [0, 0, Math.PI / 2]);
  addPip([-surf, o, -o], [0, 0, Math.PI / 2]);
  addPip([-surf, o, o], [0, 0, Math.PI / 2]);

  return diceGroup;
}

/**
 * Returns Euler angles (x, y, z) that position the target face (1..6) facing straight UP (+Y).
 */
export function getDiceTargetRotation(faceValue: number): { x: number; y: number; z: number } {
  switch (faceValue) {
    case 1: // Face 1 is already +Y
      return { x: 0, y: 0, z: 0 };
    case 6: // Face 6 is -Y -> flip 180 on X
      return { x: Math.PI, y: 0, z: 0 };
    case 2: // Face 2 is +Z -> rotate -90 on X
      return { x: -Math.PI / 2, y: 0, z: 0 };
    case 5: // Face 5 is -Z -> rotate +90 on X
      return { x: Math.PI / 2, y: 0, z: 0 };
    case 3: // Face 3 is +X -> rotate +90 on Z
      return { x: 0, y: 0, z: Math.PI / 2 };
    case 4: // Face 4 is -X -> rotate -90 on Z
      return { x: 0, y: 0, z: -Math.PI / 2 };
    default:
      return { x: 0, y: 0, z: 0 };
  }
}

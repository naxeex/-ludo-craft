import * as THREE from 'three';
import { BoardTheme, PlayerColor } from '../types/ludo';
import {
  COLOR_HEX,
  PERIMETER_PATH,
  SAFE_PERIMETER_INDICES,
  HOME_COLUMNS,
  YARD_POSITIONS,
} from '../utils/ludoRules';

export function createProceduralBoardTexture(theme: BoardTheme, maxAnisotropy = 8): THREE.CanvasTexture {
  const size = 2048;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // 15x15 board cells
  const cellSize = size / 15;

  // Background base tone
  if (theme === 'royal') {
    // Luxury Mahogany woodgrain look
    const grad = ctx.createRadialGradient(size / 2, size / 2, 50, size / 2, size / 2, size * 0.8);
    grad.addColorStop(0, '#381E11');
    grad.addColorStop(0.7, '#241209');
    grad.addColorStop(1, '#150A05');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    // Subtle wood rings
    ctx.strokeStyle = 'rgba(255, 200, 150, 0.03)';
    ctx.lineWidth = 12;
    for (let r = 80; r < size * 0.9; r += 70) {
      ctx.beginPath();
      ctx.arc(size / 2, size / 2, r, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else if (theme === 'neon') {
    // Obsidian Cyber
    ctx.fillStyle = '#080912';
    ctx.fillRect(0, 0, size, size);

    // Cyber grid lines
    ctx.strokeStyle = 'rgba(70, 100, 255, 0.08)';
    ctx.lineWidth = 1;
    for (let i = 0; i < size; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, size);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(size, i);
      ctx.stroke();
    }
  } else if (theme === 'marble') {
    // Carrara White & Gold
    const grad = ctx.createLinearGradient(0, 0, size, size);
    grad.addColorStop(0, '#F8F9FA');
    grad.addColorStop(0.5, '#E9ECEF');
    grad.addColorStop(1, '#DEE2E6');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    // Soft marble veins
    ctx.strokeStyle = 'rgba(160, 165, 175, 0.15)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, 200);
    ctx.bezierCurveTo(400, 300, 800, 100, size, 500);
    ctx.moveTo(100, size);
    ctx.bezierCurveTo(600, 1200, 1200, 1600, size - 200, 0);
    ctx.stroke();
  } else {
    // Classic Clean Ivory
    ctx.fillStyle = '#FFFDF8';
    ctx.fillRect(0, 0, size, size);
  }

  // Draw 4 Yards (6x6 cells each)
  const drawYard = (
    color: PlayerColor,
    startCol: number,
    startRow: number,
    colorStyle: string,
    accentStyle: string
  ) => {
    const x = startCol * cellSize;
    const y = startRow * cellSize;
    const w = 6 * cellSize;
    const h = 6 * cellSize;

    // Outer Yard Box
    ctx.fillStyle = colorStyle;
    ctx.fillRect(x + 4, y + 4, w - 8, h - 8);

    // Border
    ctx.strokeStyle = theme === 'royal' ? '#C5A059' : theme === 'neon' ? '#60A5FA' : '#000000';
    ctx.lineWidth = 6;
    ctx.strokeRect(x + 4, y + 4, w - 8, h - 8);

    // Inner White/Accent Yard Box
    const innerPad = cellSize * 0.75;
    ctx.fillStyle = theme === 'neon' ? '#0F172A' : theme === 'royal' ? '#1F1109' : '#FFFFFF';
    ctx.fillRect(x + innerPad, y + innerPad, w - innerPad * 2, h - innerPad * 2);

    ctx.strokeStyle = theme === 'royal' ? '#C5A059' : theme === 'neon' ? '#3B82F6' : '#222222';
    ctx.lineWidth = 4;
    ctx.strokeRect(x + innerPad, y + innerPad, w - innerPad * 2, h - innerPad * 2);

    // 4 Token circles in yard
    const yardPads = YARD_POSITIONS[color];
    yardPads.forEach((pad) => {
      const cx = (pad.col + 0.5) * cellSize;
      const cy = (pad.row + 0.5) * cellSize;
      const radius = cellSize * 0.45;

      // Drop shadow / base ring
      ctx.fillStyle = theme === 'royal' ? '#0A0503' : 'rgba(0,0,0,0.12)';
      ctx.beginPath();
      ctx.arc(cx, cy, radius + 3, 0, Math.PI * 2);
      ctx.fill();

      // Pad color circle
      ctx.fillStyle = colorStyle;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // Golden / metallic rim
      ctx.strokeStyle = theme === 'royal' ? '#F6E05E' : '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Center dot
      ctx.fillStyle = accentStyle;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 0.35, 0, Math.PI * 2);
      ctx.fill();
    });
  };

  drawYard('red', 0, 0, COLOR_HEX.red.main, COLOR_HEX.red.light);
  drawYard('green', 9, 0, COLOR_HEX.green.main, COLOR_HEX.green.light);
  drawYard('yellow', 9, 9, COLOR_HEX.yellow.main, COLOR_HEX.yellow.light);
  drawYard('blue', 0, 9, COLOR_HEX.blue.main, COLOR_HEX.blue.light);

  // Helper to draw a star
  const drawStar = (cx: number, cy: number, spikes = 8, outerRadius = cellSize * 0.36, innerRadius = cellSize * 0.18, fill = '#F59E0B') => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();
  };

  // Draw 52 Perimeter track tiles
  PERIMETER_PATH.forEach((cell, idx) => {
    const x = cell.col * cellSize;
    const y = cell.row * cellSize;

    // Determine if this is a starting square
    let cellBg = theme === 'neon' ? '#111827' : theme === 'royal' ? '#2A180E' : '#FFFFFF';
    let borderColor = theme === 'royal' ? '#6B4A34' : theme === 'neon' ? '#374151' : '#CBD5E1';
    let isStart = false;
    let startColor: PlayerColor = 'red';

    if (idx === 0) {
      cellBg = COLOR_HEX.red.main;
      isStart = true;
      startColor = 'red';
    } else if (idx === 13) {
      cellBg = COLOR_HEX.green.main;
      isStart = true;
      startColor = 'green';
    } else if (idx === 26) {
      cellBg = COLOR_HEX.yellow.main;
      isStart = true;
      startColor = 'yellow';
    } else if (idx === 39) {
      cellBg = COLOR_HEX.blue.main;
      isStart = true;
      startColor = 'blue';
    }

    ctx.fillStyle = cellBg;
    ctx.fillRect(x + 2, y + 2, cellSize - 4, cellSize - 4);

    ctx.strokeStyle = borderColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 2, y + 2, cellSize - 4, cellSize - 4);

    // If safe star square (idx in 8, 21, 34, 47)
    if ([8, 21, 34, 47].includes(idx)) {
      drawStar(
        x + cellSize / 2,
        y + cellSize / 2,
        8,
        cellSize * 0.35,
        cellSize * 0.17,
        theme === 'royal' ? '#FBBF24' : '#F59E0B'
      );
    } else if (isStart) {
      // Starting square marker: draw an arrow / star
      drawStar(
        x + cellSize / 2,
        y + cellSize / 2,
        5,
        cellSize * 0.32,
        cellSize * 0.15,
        '#FFFFFF'
      );
    }
  });

  // Draw 4 Home Columns (5 cells each)
  const drawHomeColumn = (color: PlayerColor, cells: { row: number; col: number }[]) => {
    const colorStyle = COLOR_HEX[color].main;
    // Cells 0..4 are the 5 path cells
    for (let i = 0; i < 5; i++) {
      const cell = cells[i];
      const x = cell.col * cellSize;
      const y = cell.row * cellSize;

      ctx.fillStyle = colorStyle;
      ctx.fillRect(x + 2, y + 2, cellSize - 4, cellSize - 4);

      ctx.strokeStyle = theme === 'royal' ? '#D97706' : '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.strokeRect(x + 2, y + 2, cellSize - 4, cellSize - 4);

      // Subtle step chevron or circle
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.arc(x + cellSize / 2, y + cellSize / 2, cellSize * 0.14, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  drawHomeColumn('red', HOME_COLUMNS.red);
  drawHomeColumn('green', HOME_COLUMNS.green);
  drawHomeColumn('yellow', HOME_COLUMNS.yellow);
  drawHomeColumn('blue', HOME_COLUMNS.blue);

  // Draw Center Triangle Goal (3x3 area: rows 6..8, cols 6..8)
  const centerX = 7.5 * cellSize;
  const centerY = 7.5 * cellSize;
  const leftX = 6 * cellSize;
  const rightX = 9 * cellSize;
  const topY = 6 * cellSize;
  const bottomY = 9 * cellSize;

  // Red Triangle (Left to center)
  ctx.fillStyle = COLOR_HEX.red.main;
  ctx.beginPath();
  ctx.moveTo(leftX, topY);
  ctx.lineTo(leftX, bottomY);
  ctx.lineTo(centerX, centerY);
  ctx.closePath();
  ctx.fill();

  // Green Triangle (Top to center)
  ctx.fillStyle = COLOR_HEX.green.main;
  ctx.beginPath();
  ctx.moveTo(leftX, topY);
  ctx.lineTo(rightX, topY);
  ctx.lineTo(centerX, centerY);
  ctx.closePath();
  ctx.fill();

  // Yellow Triangle (Right to center)
  ctx.fillStyle = COLOR_HEX.yellow.main;
  ctx.beginPath();
  ctx.moveTo(rightX, topY);
  ctx.lineTo(rightX, bottomY);
  ctx.lineTo(centerX, centerY);
  ctx.closePath();
  ctx.fill();

  // Blue Triangle (Bottom to center)
  ctx.fillStyle = COLOR_HEX.blue.main;
  ctx.beginPath();
  ctx.moveTo(leftX, bottomY);
  ctx.lineTo(rightX, bottomY);
  ctx.lineTo(centerX, centerY);
  ctx.closePath();
  ctx.fill();

  // Triangle dividing lines
  ctx.strokeStyle = theme === 'royal' ? '#F59E0B' : '#FFFFFF';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(leftX, topY);
  ctx.lineTo(rightX, bottomY);
  ctx.moveTo(rightX, topY);
  ctx.lineTo(leftX, bottomY);
  ctx.stroke();

  // Center Trophy / Star Medallion
  ctx.fillStyle = theme === 'royal' ? '#78350F' : '#1E293B';
  ctx.beginPath();
  ctx.arc(centerX, centerY, cellSize * 0.55, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = theme === 'royal' ? '#FBBF24' : '#FCD34D';
  ctx.lineWidth = 4;
  ctx.stroke();

  drawStar(centerX, centerY, 8, cellSize * 0.42, cellSize * 0.2, '#F59E0B');

  // Outer Border & Corner Filigrees
  ctx.strokeStyle = theme === 'royal' ? '#B45309' : theme === 'neon' ? '#3B82F6' : '#475569';
  ctx.lineWidth = 10;
  ctx.strokeRect(5, 5, size - 10, size - 10);

  // Create Three.js Texture
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

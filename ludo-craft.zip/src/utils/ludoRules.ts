import { PlayerColor, Token, MoveOption } from '../types/ludo';

export interface GridCoord {
  row: number;
  col: number;
}

// 52 perimeter steps in standard clockwise Ludo order starting from Red's start square (row 6, col 1)
export const PERIMETER_PATH: GridCoord[] = [
  /* 0  Red start */ { row: 6, col: 1 },
  /* 1            */ { row: 6, col: 2 },
  /* 2            */ { row: 6, col: 3 },
  /* 3            */ { row: 6, col: 4 },
  /* 4            */ { row: 6, col: 5 },
  /* 5  Turn up   */ { row: 5, col: 6 },
  /* 6            */ { row: 4, col: 6 },
  /* 7            */ { row: 3, col: 6 },
  /* 8  Star safe */ { row: 2, col: 6 },
  /* 9            */ { row: 1, col: 6 },
  /* 10           */ { row: 0, col: 6 },
  /* 11 Top mid   */ { row: 0, col: 7 },
  /* 12           */ { row: 0, col: 8 },
  /* 13 Grn start */ { row: 1, col: 8 },
  /* 14           */ { row: 2, col: 8 },
  /* 15           */ { row: 3, col: 8 },
  /* 16           */ { row: 4, col: 8 },
  /* 17           */ { row: 5, col: 8 },
  /* 18 Turn rgt  */ { row: 6, col: 9 },
  /* 19           */ { row: 6, col: 10 },
  /* 20           */ { row: 6, col: 11 },
  /* 21 Star safe */ { row: 6, col: 12 },
  /* 22           */ { row: 6, col: 13 },
  /* 23           */ { row: 6, col: 14 },
  /* 24 Rgt mid   */ { row: 7, col: 14 },
  /* 25           */ { row: 8, col: 14 },
  /* 26 Ylw start */ { row: 8, col: 13 },
  /* 27           */ { row: 8, col: 12 },
  /* 28           */ { row: 8, col: 11 },
  /* 29           */ { row: 8, col: 10 },
  /* 30           */ { row: 8, col: 9 },
  /* 31 Turn dwn  */ { row: 9, col: 8 },
  /* 32           */ { row: 10, col: 8 },
  /* 33           */ { row: 11, col: 8 },
  /* 34 Star safe */ { row: 12, col: 8 },
  /* 35           */ { row: 13, col: 8 },
  /* 36           */ { row: 14, col: 8 },
  /* 37 Bot mid   */ { row: 14, col: 7 },
  /* 38           */ { row: 14, col: 6 },
  /* 39 Blu start */ { row: 13, col: 6 },
  /* 40           */ { row: 12, col: 6 },
  /* 41           */ { row: 11, col: 6 },
  /* 42           */ { row: 10, col: 6 },
  /* 43           */ { row: 9, col: 6 },
  /* 44 Turn lft  */ { row: 8, col: 5 },
  /* 45           */ { row: 8, col: 4 },
  /* 46           */ { row: 8, col: 3 },
  /* 47 Star safe */ { row: 8, col: 2 },
  /* 48           */ { row: 8, col: 1 },
  /* 49           */ { row: 8, col: 0 },
  /* 50 Lft mid   */ { row: 7, col: 0 },
  /* 51           */ { row: 6, col: 0 },
];

export const COLOR_START_INDICES: Record<PlayerColor, number> = {
  red: 0,
  green: 13,
  yellow: 26,
  blue: 39,
};

// Safe squares on perimeter: starts and star squares
export const SAFE_PERIMETER_INDICES = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

// Home columns (steps 52..56) and goal (57) for each color
export const HOME_COLUMNS: Record<PlayerColor, GridCoord[]> = {
  red: [
    { row: 7, col: 1 },
    { row: 7, col: 2 },
    { row: 7, col: 3 },
    { row: 7, col: 4 },
    { row: 7, col: 5 },
    { row: 7, col: 6 },
    { row: 7, col: 7 }, // 57 is Goal
  ],
  green: [
    { row: 1, col: 7 },
    { row: 2, col: 7 },
    { row: 3, col: 7 },
    { row: 4, col: 7 },
    { row: 5, col: 7 },
    { row: 6, col: 7 },
    { row: 7, col: 7 }, // 57 is Goal
  ],
  yellow: [
    { row: 7, col: 13 },
    { row: 7, col: 12 },
    { row: 7, col: 11 },
    { row: 7, col: 10 },
    { row: 7, col: 9 },
    { row: 7, col: 8 },
    { row: 7, col: 7 }, // 57 is Goal
  ],
  blue: [
    { row: 13, col: 7 },
    { row: 12, col: 7 },
    { row: 11, col: 7 },
    { row: 10, col: 7 },
    { row: 9, col: 7 },
    { row: 8, col: 7 },
    { row: 7, col: 7 }, // 57 is Goal
  ],
};

// Yard positions for tokens 0..3 of each color
export const YARD_POSITIONS: Record<PlayerColor, GridCoord[]> = {
  red: [
    { row: 1.8, col: 1.8 },
    { row: 1.8, col: 3.8 },
    { row: 3.8, col: 1.8 },
    { row: 3.8, col: 3.8 },
  ],
  green: [
    { row: 1.8, col: 10.8 },
    { row: 1.8, col: 12.8 },
    { row: 3.8, col: 10.8 },
    { row: 3.8, col: 12.8 },
  ],
  yellow: [
    { row: 10.8, col: 10.8 },
    { row: 10.8, col: 12.8 },
    { row: 12.8, col: 10.8 },
    { row: 12.8, col: 12.8 },
  ],
  blue: [
    { row: 10.8, col: 1.8 },
    { row: 10.8, col: 3.8 },
    { row: 12.8, col: 1.8 },
    { row: 12.8, col: 3.8 },
  ],
};

export const COLOR_HEX: Record<PlayerColor, { main: string; light: string; dark: string; accent: string; hexNum: number }> = {
  red: {
    main: '#DC2626',
    light: '#F87171',
    dark: '#991B1B',
    accent: '#FECACA',
    hexNum: 0xdc2626,
  },
  green: {
    main: '#16A34A',
    light: '#4ADE80',
    dark: '#166534',
    accent: '#BBF7D0',
    hexNum: 0x16a34a,
  },
  yellow: {
    main: '#EAB308',
    light: '#FACC15',
    dark: '#A16207',
    accent: '#FEF08A',
    hexNum: 0xeab308,
  },
  blue: {
    main: '#2563EB',
    light: '#60A5FA',
    dark: '#1E40AF',
    accent: '#BFDBFE',
    hexNum: 0x2563eb,
  },
};

export const PLAYERS_ORDER: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];

export const GOAL_STEP = 57;

/**
 * Returns grid coordinate for a token at a given step.
 */
export function getCoordinatesForStep(color: PlayerColor, tokenId: number, step: number): GridCoord {
  if (step === -1) {
    return YARD_POSITIONS[color][tokenId];
  }
  if (step >= 0 && step <= 50) {
    const startIndex = COLOR_START_INDICES[color];
    const perimeterIdx = (startIndex + step) % 52;
    return PERIMETER_PATH[perimeterIdx];
  }
  if (step >= 51 && step <= GOAL_STEP) {
    const homeIdx = step - 51;
    return HOME_COLUMNS[color][homeIdx];
  }
  return { row: 7, col: 7 };
}

/**
 * Calculates board perimeter index (0..51) for token on perimeter track, or -1 otherwise.
 */
export function getPerimeterIndex(color: PlayerColor, step: number): number {
  if (step >= 0 && step <= 50) {
    const startIndex = COLOR_START_INDICES[color];
    return (startIndex + step) % 52;
  }
  return -1;
}

/**
 * Checks if a token can be moved given a dice roll value (1..6).
 */
export function getValidMoves(
  color: PlayerColor,
  tokens: Token[],
  allTokens: Token[],
  diceRoll: number
): MoveOption[] {
  const options: MoveOption[] = [];
  const playerTokens = tokens.filter((t) => t.color === color);

  for (const token of playerTokens) {
    if (token.isFinished) continue;

    // Token in yard
    if (token.isInYard || token.step === -1) {
      if (diceRoll === 6) {
        // Can enter starting square (step 0)
        const targetStep = 0;
        const targetPerimeter = COLOR_START_INDICES[color];
        // Check if there is an opponent token on start square to capture
        const hasCapture = allTokens.some(
          (other) =>
            other.color !== color &&
            !other.isFinished &&
            getPerimeterIndex(other.color, other.step) === targetPerimeter &&
            !SAFE_PERIMETER_INDICES.has(targetPerimeter)
        );

        options.push({
          tokenId: token.id,
          fromStep: -1,
          toStep: targetStep,
          isCapture: hasCapture,
          isEntering: true,
          isGoal: false,
        });
      }
      continue;
    }

    // Token on track or home stretch
    const nextStep = token.step + diceRoll;

    // Check if target step exceeds goal
    if (nextStep > GOAL_STEP) {
      continue; // Exact roll required to reach goal
    }

    const isGoal = nextStep === GOAL_STEP;
    let isCapture = false;

    // Check if target step lands on perimeter track and could capture an opponent
    if (nextStep <= 50) {
      const targetPerimeter = getPerimeterIndex(color, nextStep);
      // Safe squares cannot be captured
      if (!SAFE_PERIMETER_INDICES.has(targetPerimeter)) {
        isCapture = allTokens.some(
          (other) =>
            other.color !== color &&
            !other.isFinished &&
            getPerimeterIndex(other.color, other.step) === targetPerimeter
        );
      }
    }

    options.push({
      tokenId: token.id,
      fromStep: token.step,
      toStep: nextStep,
      isCapture,
      isEntering: false,
      isGoal,
    });
  }

  return options;
}

/**
 * AI Decision Maker with smart heuristics:
 * 1. Prioritize capturing an opponent piece!
 * 2. Prioritize entering the goal (winning point)
 * 3. Prioritize unlocking a token out of yard on a 6
 * 4. Prioritize advancing tokens close to home or moving out of danger
 * 5. Move furthest ahead token
 */
export function chooseAIMove(options: MoveOption[], tokens: Token[], allTokens: Token[]): MoveOption | null {
  if (options.length === 0) return null;
  if (options.length === 1) return options[0];

  let bestMove = options[0];
  let bestScore = -99999;

  for (const option of options) {
    let score = 0;

    // Capture is high reward (+500)
    if (option.isCapture) score += 500;

    // Reaching goal is very high reward (+400)
    if (option.isGoal) score += 400;

    // Entering the board from yard (+300)
    if (option.isEntering) score += 300;

    // Safe square bonus (+150)
    if (option.toStep <= 50) {
      const targetPerimeter = PERIMETER_PATH.findIndex(
        (_, i) => i === (COLOR_START_INDICES[tokens[0].color] + option.toStep) % 52
      );
      if (SAFE_PERIMETER_INDICES.has(targetPerimeter)) {
        score += 150;
      }
    }

    // Moving token that is in danger (+80)
    if (option.fromStep >= 0 && option.fromStep <= 50) {
      const fromPerimeter = (COLOR_START_INDICES[tokens[0].color] + option.fromStep) % 52;
      if (!SAFE_PERIMETER_INDICES.has(fromPerimeter)) {
        const hasThreat = allTokens.some(
          (other) =>
            other.color !== tokens[0].color &&
            other.step >= 0 &&
            other.step <= 50 &&
            (fromPerimeter - ((COLOR_START_INDICES[other.color] + other.step) % 52) + 52) % 52 <= 6
        );
        if (hasThreat) score += 80;
      }
    }

    // Progression score: favor pieces that make good distance
    score += option.toStep * 2;

    if (score > bestScore) {
      bestScore = score;
      bestMove = option;
    }
  }

  return bestMove;
}
